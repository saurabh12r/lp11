// Optional interactivity if needed
console.log("Airline Reservation System Loaded");
